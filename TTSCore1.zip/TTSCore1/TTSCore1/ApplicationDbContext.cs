﻿using Microsoft.EntityFrameworkCore;
using TTSCore1.Models;

namespace TTSCore1
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }
        public DbSet<UserMasterModel> UserMasterModel { get; set; }
       
    }
}
