﻿using Microsoft.AspNetCore.Mvc;
using TTSCore1.Models;

namespace TTSCore1.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AccountController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = _context.UserMasterModel.FirstOrDefault(u => u.PUserName == model.Username && u.PPassword == model.Password);

                if (user != null)
                {
                    // User authenticated, set authentication cookie or claims
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelError("", "Invalid login attempt.");
                }
            }
            return View(model);
        }
    }
}
