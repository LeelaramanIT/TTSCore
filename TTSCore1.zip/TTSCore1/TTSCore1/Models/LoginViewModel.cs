﻿using System.ComponentModel.DataAnnotations;

namespace TTSCore1.Models
{
    public class LoginViewModel
    {
        [Key]
        public int id { get; set; } 
        [Required]
        public string Username { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
