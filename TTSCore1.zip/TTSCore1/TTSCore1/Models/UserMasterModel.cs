﻿using System.ComponentModel.DataAnnotations;

namespace TTSCore1.Models
{
    public class UserMasterModel
    {
        [Key]
        public int PUserID { get; set; }
        [Required]
        public string PUserName { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string PPassword { get; set; } = string.Empty;
        public string PEmail { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string UserName { get; set; }
        public string UserType { get; set; }
        public DateTime LastLogin {  get; set; }
        public int LoginStatus { get; set; }
        public int ChatLogin {  get; set; }
        public string UserChannel { get; set; }
        public string UserDepartment {  get; set; }
    }
}
